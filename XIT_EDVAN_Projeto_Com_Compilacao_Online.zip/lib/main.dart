import 'package:flutter/material.dart';

void main() => runApp(const XitEdvanApp());

const blue = Color(0xFF159BFF);
const background = Color(0xFF070B14);
const panel = Color(0xFF101A2A);

class XitEdvanApp extends StatelessWidget {
  const XitEdvanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'XIT EDVAN',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: blue,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const PanelPage(),
    );
  }
}

class PanelPage extends StatefulWidget {
  const PanelPage({super.key});

  @override
  State<PanelPage> createState() => _PanelPageState();
}

class _PanelPageState extends State<PanelPage> {
  bool crosshair = true;
  bool performance = false;
  double general = 90;
  double redDot = 85;
  double scope2x = 80;
  double scope4x = 75;
  final dpiController = TextEditingController(text: 'Padrão do aparelho');

  @override
  void dispose() {
    dpiController.dispose();
    super.dispose();
  }

  Widget sectionCard({required Widget child}) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: panel,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: blue.withOpacity(.35)),
    ),
    child: child,
  );

  Widget settingSwitch(String title, String subtitle, bool value,
      ValueChanged<bool> onChanged, IconData icon) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: blue, size: 28),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60)),
      trailing: Switch(
        value: value,
        activeColor: blue,
        onChanged: onChanged,
      ),
    );
  }

  Widget sensitivity(String title, double value, ValueChanged<double> change) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title),
            Text(value.round().toString(),
                style: const TextStyle(color: blue, fontWeight: FontWeight.bold)),
          ],
        ),
        Slider(
          value: value,
          min: 0,
          max: 100,
          divisions: 100,
          activeColor: blue,
          onChanged: change,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: background,
        centerTitle: true,
        title: const Text('⚡ XIT EDVAN',
            style: TextStyle(
              color: blue,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            )),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(
                colors: [Color(0xFF102C50), Color(0xFF080D18)],
              ),
              border: Border.all(color: blue, width: 1.2),
            ),
            child: const Column(
              children: [
                Icon(Icons.bolt, color: blue, size: 38),
                SizedBox(height: 8),
                Text('XIT EDVAN',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 2,
                    )),
                Text('PAINEL AUXILIAR • PRETO & AZUL',
                    style: TextStyle(color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          sectionCard(
            child: Column(
              children: [
                settingSwitch(
                  'Mira visual de treino',
                  'Exibe apenas uma referência visual nesta tela',
                  crosshair,
                  (v) => setState(() => crosshair = v),
                  Icons.center_focus_strong,
                ),
                if (crosshair)
                  Container(
                    height: 90,
                    alignment: Alignment.center,
                    child: const Icon(Icons.add, color: blue, size: 54),
                  ),
                const Divider(color: Colors.white12),
                settingSwitch(
                  'Modo economia',
                  'Dica visual para priorizar economia de bateria',
                  performance,
                  (v) => setState(() => performance = v),
                  Icons.battery_saver,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          sectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('SENSIBILIDADE',
                    style: TextStyle(
                      color: blue,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    )),
                const SizedBox(height: 12),
                sensitivity('Geral', general, (v) => setState(() => general = v)),
                sensitivity('Ponto vermelho', redDot, (v) => setState(() => redDot = v)),
                sensitivity('Mira 2x', scope2x, (v) => setState(() => scope2x = v)),
                sensitivity('Mira 4x', scope4x, (v) => setState(() => scope4x = v)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          sectionCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('DPI / TELA',
                    style: TextStyle(
                      color: blue,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.4,
                    )),
                const SizedBox(height: 8),
                const Text(
                  'Consulte as configurações de tela do próprio aparelho. '
                  'Este painel não altera o DPI automaticamente.',
                  style: TextStyle(color: Colors.white60),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: dpiController,
                  decoration: const InputDecoration(
                    labelText: 'Anotação pessoal',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Aviso: este é um painel auxiliar. Não injeta código, não automatiza tiros, '
            'não modifica o Free Fire e não oferece “anti-ban”. Os controles são apenas '
            'anotações e pré-visualizações.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54, fontSize: 12),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
